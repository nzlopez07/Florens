"""
Inicializador de tests.
"""

__all__ = []
