"""
Inicializador del módulo whatsapp (servicios de WhatsApp).
"""

from .whatsapp_message_service import WhatsAppMessageService

__all__ = ["WhatsAppMessageService"]
